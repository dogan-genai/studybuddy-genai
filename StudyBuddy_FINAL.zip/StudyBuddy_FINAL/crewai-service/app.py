from fastapi import FastAPI
from pydantic import BaseModel
from agents import create_plan_crew, create_quiz_crew, create_explain_crew, motivator_agent
from crewai import Task, Crew

app = FastAPI()

class PlanRequest(BaseModel):
    student_profile: dict
    goal: str

class QuizRequest(BaseModel):
    query: str
    course_id: str
    num_questions: int = 3

class ExplainRequest(BaseModel):
    question: str
    course_id: str

class MotivateRequest(BaseModel):
    context: str
    progress: dict

@app.post("/crew/plan")
async def generate_plan(req: PlanRequest):
    crew = create_plan_crew(req.student_profile, req.goal)
    result = crew.kickoff()
    return {"result": result}

@app.post("/crew/quiz")
async def generate_quiz(req: QuizRequest):
    crew = create_quiz_crew(req.query, req.course_id, req.num_questions)
    result = crew.kickoff()
    return {"result": result}

@app.post("/crew/explain")
async def explain_concept(req: ExplainRequest):
    crew = create_explain_crew(req.question, req.course_id)
    result = crew.kickoff()
    return {"result": result}

@app.post("/crew/motivate")
async def motivate_student(req: MotivateRequest):
    task = Task(
        description=f"""
        Provide motivation for context: {req.context}
        Progress: {req.progress}
        
        Give encouraging feedback and study tips.
        """,
        agent=motivator_agent,
        expected_output="Motivational message"
    )
    
    crew = Crew(
        agents=[motivator_agent],
        tasks=[task]
    )
    
    result = crew.kickoff()
    return {"result": result}
