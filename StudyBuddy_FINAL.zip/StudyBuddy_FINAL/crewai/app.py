import os
import json
import re
import traceback
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from crewai import Agent, Task, Crew, Process

load_dotenv()

# ---- Ollama LLM (local-only) ----
def get_ollama_llm():
    base_url = os.getenv("OLLAMA_BASE_URL", os.getenv("OLLAMA_URL", "http://host.docker.internal:11434"))
    model = os.getenv("LLM_MODEL", os.getenv("OLLAMA_MODEL", "gemma3:4b"))
    print("[CrewAI] Using Ollama:", base_url, "| model:", model)

    # Prefer langchain_ollama; fallback to langchain_community
    try:
        from langchain_ollama import ChatOllama
        return ChatOllama(base_url=base_url, model=model, temperature=0)
    except Exception:
        from langchain_community.chat_models import ChatOllama
        return ChatOllama(base_url=base_url, model=model, temperature=0)

app = FastAPI(title="StudyBuddy CrewAI Service")

@app.exception_handler(Exception)
async def all_exception_handler(request: Request, exc: Exception):
    tb = traceback.format_exc()
    print("=== UNHANDLED ERROR ===")
    print(tb)
    return JSONResponse(
        status_code=500,
        content={"ok": False, "error": str(exc), "traceback": tb}
    )

# ---- Models ----
class CrewRequest(BaseModel):
    goal: Optional[str] = None
    scope: Optional[str] = None
    time_budget_hours_per_week: Optional[int] = None
    chunks: List[Dict[str, Any]]

class TutorRequest(BaseModel):
    student_profile: Dict[str, Any]
    question: str
    progress: Optional[Dict[str, Any]] = None
    retrieved_chunks: List[Dict[str, Any]]

# ---- Helpers ----
def context_block(chunks: List[Dict[str, Any]], limit: int = 4) -> str:
    out = []
    for i, c in enumerate(chunks[:limit], start=1):
        out.append(
            f"[#{i}] source={c.get('source')} page={c.get('page')} course_tag={c.get('course_tag')} chunk_id={c.get('chunk_id')}\n"
            f"{c.get('text')}"
        )
    return "\n\n".join(out)

def _strip_code_fences(text: str) -> str:
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.IGNORECASE)
    t = re.sub(r"\s*```\s*$", "", t)
    return t.strip()

def _extract_first_json_object(text: str) -> Optional[str]:
    s = text or ""
    i = s.find("{")
    j = s.rfind("}")
    if i >= 0 and j > i:
        return s[i:j+1]
    return None

def clean_json(text: str) -> Dict[str, Any]:
    t = _strip_code_fences(str(text))
    obj = _extract_first_json_object(t) or t
    try:
        return json.loads(obj)
    except Exception as e:
        return {"ok": False, "error": f"JSON_PARSE_ERROR: {type(e).__name__}: {e}", "raw": t[:8000]}

def make_agents():
    llm = get_ollama_llm()
    planner = Agent(
        role="Planner",
        goal="Create a personalized weekly study plan based ONLY on provided context.",
        backstory="You structure learning into sessions and tasks, grounded in citations.",
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )
    reviewer = Agent(
        role="Reviewer",
        goal="Ensure output is valid JSON, includes evidence citations, and does not invent facts.",
        backstory="You repair JSON and enforce evidence. If insufficient context: refuse.",
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )
    tutor = Agent(
        role="Explainer",
        goal="Answer the user's question using ONLY retrieved chunks with citations. Refuse if insufficient.",
        backstory="You are a grounded tutor. Every claim needs citations.",
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )
    return planner, reviewer, tutor

# ---- Routes ----
@app.post("/crew/plan")
def crew_plan(req: CrewRequest):
    try:
        ctx = context_block(req.chunks)
        goal = req.goal or "Exam preparation"
        scope = req.scope or "all"
        tb = int(req.time_budget_hours_per_week or 6)

        planner, reviewer, _ = make_agents()

        schema = f"""
Return ONLY valid JSON (no markdown). Use exactly this shape:
{{
  "ok": true|false,
  "active_course_used": "{scope}",
  "weekly_plan": {{
    "total_minutes": <int>,
    "days": [
      {{
        "day": "Mon|Tue|Wed|Thu|Fri|Sat|Sun",
        "tasks": [
          {{
            "title": "<string>",
            "minutes": <int>,
            "task_type": "reading|practice|quiz|review",
            "evidence": [
              {{"source":"<string>","page":<int>,"chunk_id":"<string>","course_tag":"{scope}"}}
            ]
          }}
        ]
      }}
    ]
  }} | null,
  "refusal": null | {{
    "reason":"insufficient_evidence|invalid_scope|other",
    "details":"<string>"
  }}
}}

RULES:
- Use ONLY the provided chunks. No external knowledge.
- Each task MUST include >=1 evidence item copied from chunk metadata (source/page/chunk_id/course_tag).
- evidence.course_tag MUST equal "{scope}".
- Time budget: {tb} hours/week (= {tb*60} minutes). total_minutes should match budget roughly.
- If insufficient context: ok=false and refusal.reason="insufficient_evidence".
"""

        plan_task = Task(
            description=(
                f"GOAL: {goal}\nSCOPE: {scope}\nTIME_BUDGET_HOURS_PER_WEEK: {tb}\n\n"
                f"CHUNKS:\n{ctx}\n\n"
                f"{schema}"
            ),
            expected_output="Valid JSON only. No markdown.",
            agent=planner,
        )

        crew = Crew(
            agents=[planner],
            tasks=[plan_task],
            process=Process.sequential,
            verbose=False,
        )

        result = crew.kickoff()
        return clean_json(str(result))

    except Exception as e:
        tb = traceback.format_exc()
        print("=== /crew/plan ERROR ===")
        print(tb)
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e), "traceback": tb})

@app.post("/crew/tutor")
def crew_tutor(req: TutorRequest):
    try:
        _, _, tutor = make_agents()
        ctx = context_block(req.retrieved_chunks)

        schema = """
Return ONLY valid JSON (no markdown):
{
  "ok": true|false,
  "answer": "<string>" | null,
  "citations": [
    {"source":"<string>","page":<int>,"chunk_id":"<string>","course_tag":"<string>"}
  ],
  "refusal": null | {"reason":"insufficient_evidence","details":"<string>"}
}

RULES:
- Use ONLY retrieved_chunks content. No external knowledge.
- Every claim must be supported by citations.
- If insufficient context: ok=false with refusal.
"""

        task = Task(
            description=(
                f"QUESTION: {req.question}\n\n"
                f"RETRIEVED_CHUNKS:\n{ctx}\n\n"
                f"{schema}"
            ),
            expected_output="Valid JSON only. No markdown.",
            agent=tutor,
        )

        crew = Crew(agents=[tutor], tasks=[task], process=Process.sequential, verbose=True)
        result = crew.kickoff()
        return clean_json(str(result))

    except Exception as e:
        tb = traceback.format_exc()
        print("=== /crew/tutor ERROR ===")
        print(tb)
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e), "traceback": tb})

@app.get("/health")
def health():
    return {"status": "ok", "service": "crewai"}
